package model;

public enum Terrain {
	GRASS, WATER, MOUNTAIN;
}
